﻿namespace TicTacToeGameServer.Interfaces
{
    public interface IRandomizerService
    {
        int GetRandomNumber(int min, int max);
    }
}
