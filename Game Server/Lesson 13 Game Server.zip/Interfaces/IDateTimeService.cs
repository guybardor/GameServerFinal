﻿namespace TicTacToeGameServer.Interfaces
{
    public interface IDateTimeService
    {
        public string GetUtcTime();
    }
}
